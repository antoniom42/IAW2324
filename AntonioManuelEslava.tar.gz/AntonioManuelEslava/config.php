<?php
        define('usuario', 'usuario');
        define('contrasena', 'usuario');
?>